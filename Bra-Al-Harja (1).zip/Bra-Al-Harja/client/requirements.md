## Packages
framer-motion | Essential for the 3s suspense reveal animation and page transitions
canvas-confetti | For celebration effects when the game ends
@types/canvas-confetti | Types for confetti
use-sound | For handling sound effects (click, suspense, reveal)

## Notes
The game logic is primarily client-side.
State is persisted in localStorage for player names.
Audio files will be referenced via public URLs or base64 if small.
RTL layout is mandatory for Arabic support.

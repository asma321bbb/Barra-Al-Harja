import { ReactNode } from "react";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen w-full bg-slate-950 dark:bg-slate-950 light:bg-slate-50 text-foreground flex flex-col items-center relative overflow-hidden transition-colors duration-300">
      {/* Background Gradients */}
      <div className="fixed top-0 left-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
      <div className="fixed bottom-0 right-0 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2 pointer-events-none" />
      
      {/* Main Content Container */}
      <main className="w-full max-w-md mx-auto p-6 flex flex-col flex-1 relative z-10 min-h-screen text-slate-100 light:text-slate-900 dark:text-slate-100">
        {children}
      </main>
    </div>
  );
}

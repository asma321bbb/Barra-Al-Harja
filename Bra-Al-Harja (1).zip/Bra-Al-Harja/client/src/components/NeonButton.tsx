import { cn } from "@/lib/utils";
import { motion, HTMLMotionProps } from "framer-motion";

interface NeonButtonProps extends HTMLMotionProps<"button"> {
  variant?: "primary" | "secondary" | "danger" | "ghost";
  size?: "sm" | "md" | "lg";
}

export function NeonButton({ 
  className, 
  variant = "primary", 
  size = "md", 
  children, 
  ...props 
}: NeonButtonProps) {
  
  const variants = {
    primary: "bg-primary/20 border-primary text-primary hover:bg-primary/30 hover:shadow-[0_0_20px_rgba(139,92,246,0.4)]",
    secondary: "bg-secondary/20 border-secondary text-secondary hover:bg-secondary/30 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)]",
    danger: "bg-destructive/20 border-destructive text-destructive hover:bg-destructive/30 hover:shadow-[0_0_20px_rgba(239,68,68,0.4)]",
    ghost: "bg-transparent border-transparent text-muted-foreground hover:text-foreground hover:bg-white/5",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-xl font-bold",
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        "relative rounded-xl border-2 transition-all duration-300 flex items-center justify-center gap-2 outline-none focus:ring-2 ring-offset-2 ring-offset-background",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </motion.button>
  );
}

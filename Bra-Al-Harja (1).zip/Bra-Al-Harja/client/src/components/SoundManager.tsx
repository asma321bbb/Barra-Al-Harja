// Simple utility to manage sounds
const sounds = {
  click: new Audio("https://cdn.pixabay.com/audio/2022/03/15/audio_2d039750b3.mp3"), // Soft click
  suspense: new Audio("https://cdn.pixabay.com/audio/2022/03/19/audio_82c122044f.mp3"), // Glitch/Static
  reveal: new Audio("https://cdn.pixabay.com/audio/2022/03/10/audio_c8c8a73467.mp3"), // Whoosh
  spy: new Audio("https://cdn.pixabay.com/audio/2021/08/04/audio_12b0c7443c.mp3"), // Dramatic hit
};

// Preload sounds
Object.values(sounds).forEach(s => {
  s.load();
  s.volume = 0.5;
});

export const playSound = (type: keyof typeof sounds) => {
  try {
    const sound = sounds[type];
    sound.currentTime = 0;
    sound.play().catch(e => console.log("Audio play blocked", e));
  } catch (e) {
    console.error("Sound error", e);
  }
};

export function SoundControl() {
  return null; // Logic only
}

import { useState, useEffect } from 'react';

// --- Types ---
export type Category = 
  | "اكلات" 
  | "مسلسلات" 
  | "حيوانات" 
  | "ملابس" 
  | "انمي" 
  | "سبيستون" 
  | "مهن ووظائف" 
  | "دول ومدن"
  | "كيبوب"
  | "كيدراما";

export interface Player {
  id: string;
  name: string;
}

export type GamePhase = 'setup' | 'category' | 'pass' | 'reveal' | 'wait' | 'vote' | 'guess' | 'end';

// --- Data ---
const WORDS: Record<Category, string[]> = {
  "اكلات": ["كبسة", "بيتزا", "سوشي", "برجر", "شاورما", "فلافل", "مندي", "مسخن", "كشري", "منسف", "جريش", "قرصان", "سليق", "معصوب", "مطبق"],
  "مسلسلات": ["باب الحارة", "طاش ما طاش", "شباب البومب", "رشاش", "فريندز", "بريكينج باد", "لعبة الحبار", "المكتب", "سترينجر ثينقز", "بيكي بلايندرز"],
  "حيوانات": ["أسد", "فيل", "زرافة", "قطة", "كلب", "نمر", "ذئب", "صقر", "بطريق", "دب", "كنغر", "حوت", "قرش", "تمساح"],
  "ملابس": ["ثوب", "شماغ", "جينز", "تيشيرت", "فستان", "عباية", "جاكيت", "قبعة", "حذاء", "شراب", "بشت", "سديري"],
  "انمي": ["ون بيس", "ناروتو", "هجوم العمالقة", "ديت نوت", "دراغون بول", "هنتر", "ديمون سلاير", "جوجوتسو كايسن", "بليتش", "كونان"],
  "سبيستون": ["سابق ولاحق", "بوكيمون", "أبطال الديجيتال", "المحقق كونان", "دروب ريمي", "أنا وأخي", "عهد الأصدقاء", "القناص", "باتمان", "سوبرمان"],
  "مهن ووظائف": ["طبيب", "مهندس", "معلم", "شرطي", "طيار", "مبرمج", "نجار", "طباخ", "محامي", "رائد فضاء", "رسام", "مزارع"],
  "دول ومدن": ["السعودية", "مصر", "الرياض", "دبي", "لندن", "باريس", "اليابان", "كوريا", "مكة", "جدة", "القاهرة", "فلسطين"],
  "كيبوب": ["بي تي اس", "بلاك بينك", "اكسو", "توايس", "ريد فيلفيت", "ستراي كيدز", "نيوجينز", "سفنتين", "ايتيز", "ان هايبر"],
  "كيدراما": ["لعبة الحبار", "هبوط اضطراري للحب", "الجمال الحقيقي", "فتيان قبل الزهور", "الطبيب الجيد", "خلف كل نجم", "المحامي الاستثنائي", "فينتشنزو", "بينوكيو", "ثق في"]
};

// --- Hook ---
export function useGameLogic() {
  const [players, setPlayers] = useState<Player[]>(() => {
    const saved = localStorage.getItem('bra-alharja-players');
    return saved ? JSON.parse(saved) : [];
  });

  const [gamePhase, setGamePhase] = useState<GamePhase>('setup');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [secretWord, setSecretWord] = useState<string>("");
  const [spyIndex, setSpyIndex] = useState<number>(-1);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [starterIndex, setStarterIndex] = useState<number>(-1);
  const [guessOptions, setGuessOptions] = useState<string[]>([]);
  const [guessResult, setGuessResult] = useState<'correct' | 'wrong' | null>(null);

  // Save players whenever they change
  useEffect(() => {
    localStorage.setItem('bra-alharja-players', JSON.stringify(players));
  }, [players]);

  const addPlayer = (name: string) => {
    if (!name.trim()) return;
    setPlayers([...players, { id: crypto.randomUUID(), name: name.trim() }]);
  };

  const removePlayer = (id: string) => {
    setPlayers(players.filter(p => p.id !== id));
  };

  const startGame = (category: Category) => {
    if (players.length < 3) {
      alert("تحتاج 3 لاعبين على الأقل!");
      return;
    }

    const categoryWords = WORDS[category];
    const word = categoryWords[Math.floor(Math.random() * categoryWords.length)];
    const newSpyIndex = Math.floor(Math.random() * players.length);
    const newStarterIndex = Math.floor(Math.random() * players.length);

    // Prepare guess options
    const otherWords = categoryWords.filter(w => w !== word);
    const shuffledOthers = [...otherWords].sort(() => 0.5 - Math.random());
    const options = [word, ...shuffledOthers.slice(0, 4)].sort(() => 0.5 - Math.random());

    setSelectedCategory(category);
    setSecretWord(word);
    setSpyIndex(newSpyIndex);
    setStarterIndex(newStarterIndex);
    setCurrentPlayerIndex(0);
    setGuessOptions(options);
    setGuessResult(null);
    setGamePhase('pass');
  };

  const nextPlayer = () => {
    if (currentPlayerIndex < players.length - 1) {
      setCurrentPlayerIndex(prev => prev + 1);
      setGamePhase('pass');
    } else {
      setGamePhase('wait');
    }
  };

  const checkGuess = (word: string) => {
    if (word === secretWord) {
      setGuessResult('correct');
    } else {
      setGuessResult('wrong');
    }
  };

  const resetGame = (keepCategory: boolean = false) => {
    if (keepCategory && selectedCategory) {
      startGame(selectedCategory);
    } else {
      setGamePhase('setup');
      setSelectedCategory(null);
      setSecretWord("");
      setSpyIndex(-1);
      setCurrentPlayerIndex(0);
      setStarterIndex(-1);
      setGuessOptions([]);
      setGuessResult(null);
    }
  };

  return {
    players,
    addPlayer,
    removePlayer,
    gamePhase,
    setGamePhase,
    selectedCategory,
    startGame,
    currentPlayer: players[currentPlayerIndex],
    isSpy: currentPlayerIndex === spyIndex,
    secretWord,
    spyIndex,
    starterPlayer: players[starterIndex],
    guessOptions,
    guessResult,
    checkGuess,
    allPlayers: players,
    nextPlayer,
    resetGame,
    CATEGORIES: Object.keys(WORDS) as Category[]
  };
}

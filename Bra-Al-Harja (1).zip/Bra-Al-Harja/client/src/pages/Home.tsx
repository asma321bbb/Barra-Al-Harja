import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, X, User, Play, Info, Moon, Sun, RotateCcw, Vote } from "lucide-react";
import { useGameLogic, Category } from "@/hooks/use-game-logic";
import { NeonButton } from "@/components/NeonButton";
import { Layout } from "@/components/Layout";
import { playSound } from "@/components/SoundManager";
import { cn } from "@/lib/utils";
import confetti from "canvas-confetti";

export default function Game() {
  const {
    players,
    addPlayer,
    removePlayer,
    gamePhase,
    setGamePhase,
    startGame,
    currentPlayer,
    isSpy,
    secretWord,
    spyIndex,
    allPlayers,
    nextPlayer,
    resetGame,
    CATEGORIES,
    starterPlayer,
    guessOptions,
    guessResult,
    checkGuess
  } = useGameLogic();

  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const toggleTheme = () => {
    const newTheme = theme === "dark" ? "light" : "dark";
    setTheme(newTheme);
    playSound("click");
  };

  // --- Render Functions based on Phase ---

  if (gamePhase === "setup") {
    return (
      <SetupScreen
        players={players}
        onAdd={addPlayer}
        onRemove={removePlayer}
        onNext={() => {
          playSound("click");
          if (players.length >= 3) setGamePhase("category");
          else alert("أضف 3 لاعبين على الأقل");
        }}
        onToggleTheme={toggleTheme}
        theme={theme}
      />
    );
  }

  if (gamePhase === "category") {
    return (
      <CategoryScreen
        categories={CATEGORIES}
        onSelect={(cat) => {
          playSound("click");
          startGame(cat);
        }}
        onBack={() => {
          playSound("click");
          setGamePhase("setup");
        }}
      />
    );
  }

  if (gamePhase === "pass") {
    return (
      <PassScreen
        playerName={currentPlayer.name}
        onReady={() => {
          playSound("click");
          setGamePhase("reveal");
        }}
      />
    );
  }

  if (gamePhase === "reveal") {
    return (
      <RevealScreen
        isSpy={isSpy}
        secretWord={secretWord}
        onHide={() => {
          playSound("click");
          nextPlayer();
        }}
      />
    );
  }

  if (gamePhase === "wait") {
    return (
      <WaitScreen
        starterPlayer={starterPlayer?.name}
        onVote={() => {
          playSound("click");
          setGamePhase("vote");
        }}
      />
    );
  }

  if (gamePhase === "vote") {
    return (
      <VoteScreen
        allPlayers={allPlayers}
        spyIndex={spyIndex}
        onReveal={() => {
          setGamePhase("guess");
        }}
      />
    );
  }

  if (gamePhase === "guess") {
    return (
      <GuessScreen
        spyName={allPlayers[spyIndex]?.name}
        options={guessOptions}
        result={guessResult}
        onGuess={(opt) => {
          playSound("click");
          checkGuess(opt);
        }}
        onEnd={() => {
          playSound("click");
          setGamePhase("end");
        }}
      />
    );
  }

  if (gamePhase === "end") {
    return (
      <EndScreen
        spyName={allPlayers[spyIndex]?.name}
        onReset={() => {
          playSound("click");
          resetGame();
        }}
        onRepeat={() => {
          playSound("click");
          resetGame(true);
        }}
      />
    );
  }

  return null;
}

// --- Sub-Screens ---

function SetupScreen({
  players,
  onAdd,
  onRemove,
  onNext,
  onToggleTheme,
  theme,
}: {
  players: { id: string; name: string }[];
  onAdd: (name: string) => void;
  onRemove: (id: string) => void;
  onNext: () => void;
  onToggleTheme: () => void;
  theme: "dark" | "light";
}) {
  const [name, setName] = useState("");

  const handleAdd = () => {
    if (name.trim()) {
      onAdd(name);
      setName("");
      playSound("click");
    }
  };

  return (
    <Layout>
      <div className="flex flex-col h-full gap-8">
        <header className="flex justify-between items-center mt-4">
          <div className="w-10" />
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-primary via-white to-secondary text-glow tracking-wide pb-1"
            style={{ fontFamily: "Cairo", lineHeight: 1.2 }}
          >
            برا الهرجة
          </motion.h1>
          <button onClick={onToggleTheme} className="p-2 bg-white/5 rounded-full border border-white/10 text-white dark:text-white light:text-slate-900">
            {theme === "dark" ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
          </button>
        </header>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex-1 bg-white/5 rounded-3xl p-6 border border-white/10 backdrop-blur-md flex flex-col gap-4"
        >
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-bold flex items-center gap-2 text-secondary">
              <User className="w-5 h-5" />
              قائمة اللاعبين
            </h2>
            <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm font-bold mr-auto">
              {players.length}
            </span>
          </div>

          <div className="flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
              placeholder="اسم اللاعب..."
              className="flex-1 bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-lg focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground/50 text-white dark:text-white light:text-slate-900"
            />
            <button
              onClick={handleAdd}
              className="bg-primary text-white p-3 rounded-xl hover:bg-primary/80 transition-colors"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 -mr-1 custom-scrollbar min-h-[200px]">
            <AnimatePresence mode="popLayout">
              {players.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50"
                >
                  <User className="w-12 h-12 mb-2" />
                  <p>لا يوجد لاعبين بعد</p>
                </motion.div>
              )}
              {players.map((p) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/5 group hover:border-primary/30 transition-colors"
                >
                  <span className="font-semibold text-lg text-white dark:text-white light:text-slate-900">{p.name}</span>
                  <button
                    onClick={() => {
                      playSound("click");
                      onRemove(p.id);
                    }}
                    className="text-muted-foreground hover:text-destructive transition-colors p-2"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>

        <div className="space-y-4 mb-4">
          {players.length < 3 && (
            <p className="text-center text-destructive text-sm bg-destructive/10 py-2 rounded-lg">
              تحتاج 3 لاعبين على الأقل لبدء اللعبة
            </p>
          )}
          <NeonButton
            onClick={onNext}
            disabled={players.length < 3}
            className="w-full text-xl py-6 font-bold"
            size="lg"
          >
            اختر الفئة
            <Play className="w-6 h-6 mr-2 rotate-180" />
          </NeonButton>
        </div>
      </div>
    </Layout>
  );
}

function CategoryScreen({
  categories,
  onSelect,
  onBack,
}: {
  categories: Category[];
  onSelect: (c: Category) => void;
  onBack: () => void;
}) {
  return (
    <Layout>
      <div className="flex flex-col h-full gap-6 py-4">
        <div className="flex items-center justify-between">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full text-white dark:text-white light:text-slate-900">
            <X className="w-6 h-6" />
          </button>
          <h2 className="text-2xl font-bold text-secondary text-glow-cyan">اختر الموضوع</h2>
          <div className="w-10" />
        </div>

        <div className="grid grid-cols-2 gap-4 flex-1 overflow-y-auto pb-20">
          {categories.map((cat, i) => (
            <motion.button
              key={cat}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => onSelect(cat)}
              className="aspect-square rounded-3xl bg-gradient-to-br from-white/10 to-transparent border border-white/10 hover:border-primary hover:bg-primary/10 transition-all flex flex-col items-center justify-center gap-4 group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60" />
              <span className="text-5xl relative z-10 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                {getCategoryIcon(cat)}
              </span>
              <span className="text-xl font-bold relative z-10 text-center px-2 group-hover:text-primary transition-colors text-white dark:text-white light:text-slate-900">
                {cat}
              </span>
            </motion.button>
          ))}
        </div>
      </div>
    </Layout>
  );
}

function PassScreen({ playerName, onReady }: { playerName: string; onReady: () => void }) {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full gap-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-center space-y-6"
        >
          <div className="w-32 h-32 mx-auto bg-primary/20 rounded-full flex items-center justify-center border-4 border-primary shadow-[0_0_40px_rgba(139,92,246,0.3)] animate-pulse">
            <User className="w-16 h-16 text-primary" />
          </div>
          <div className="space-y-2">
            <p className="text-muted-foreground text-xl">أعط الجوال لـ</p>
            <h2 className="text-5xl font-black text-white dark:text-white light:text-slate-900 py-2">{playerName}</h2>
          </div>
        </motion.div>
        <NeonButton
          onClick={onReady}
          className="w-full max-w-xs text-xl py-6 mt-12"
          variant="secondary"
        >
          أنا {playerName}، ورني!
        </NeonButton>
      </div>
    </Layout>
  );
}

function RevealScreen({
  isSpy,
  secretWord,
  onHide,
}: {
  isSpy: boolean;
  secretWord: string;
  onHide: () => void;
}) {
  const [revealed, setRevealed] = useState(false);

  const handleReveal = () => {
    playSound("reveal");
    setRevealed(true);
    if (isSpy) {
      playSound("spy");
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full gap-8 relative">
        <div className="relative w-full aspect-[3/4] max-h-[500px]">
          <AnimatePresence mode="wait">
            {!revealed ? (
              <motion.div
                key="hidden"
                initial={{ rotateY: 90 }}
                animate={{ rotateY: 0 }}
                exit={{ rotateY: -90 }}
                className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl border-2 border-white/10 flex flex-col items-center justify-center cursor-pointer shadow-2xl"
                onClick={handleReveal}
              >
                <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-6 border border-white/10">
                  <Play className="w-10 h-10 text-white ml-1" />
                </div>
                <h3 className="text-3xl font-bold text-white/70">اضغط للكشف</h3>
              </motion.div>
            ) : (
              <motion.div
                key="revealed"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className={cn(
                  "absolute inset-0 rounded-3xl flex flex-col items-center justify-center p-8 text-center border-4 shadow-[0_0_50px_rgba(0,0,0,0.5)]",
                  isSpy
                    ? "bg-destructive border-destructive text-white"
                    : "bg-gradient-to-br from-primary to-purple-900 border-primary text-white"
                )}
              >
                {isSpy ? (
                  <>
                    <h2 className="text-4xl font-black mb-6 leading-tight drop-shadow-md">أنت برا الهرجة.. شد حيلك!</h2>
                    <p className="text-xl opacity-90 font-medium">حاول تكتشف السالفة من كلامهم ولا ينكشف أمرك! 😉</p>
                    <div className="mt-8 text-6xl">🤫</div>
                  </>
                ) : (
                  <>
                    <p className="text-lg opacity-80 mb-2">السالفة هي</p>
                    <h2 className="text-6xl font-black mb-8 text-glow drop-shadow-xl bg-black/20 py-4 px-6 rounded-2xl w-full">
                      {secretWord}
                    </h2>
                    <p className="text-xl opacity-90">أنت داخل الهرجة، لا تفضح نفسك وحاول تصيد اللي برا!</p>
                  </>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {revealed && (
          <NeonButton onClick={onHide} className="w-full text-xl py-6 mt-4" variant={isSpy ? "danger" : "primary"}>
            خبيت، اللي بعده
          </NeonButton>
        )}
      </div>
    </Layout>
  );
}

function WaitScreen({ starterPlayer, onVote }: { starterPlayer?: string; onVote: () => void }) {
  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full gap-8 text-center">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="space-y-6">
          <h2 className="text-4xl font-black text-glow">وقت الأسئلة!</h2>
          <div className="bg-white/5 p-6 rounded-3xl border border-white/10 space-y-4">
            <p className="text-muted-foreground">اللي بيبدأ السؤال هو:</p>
            <div className="text-4xl font-black text-secondary">{starterPlayer}</div>
          </div>
          <p className="text-lg text-muted-foreground/80 px-4">
            اسألوا بعض أسئلة ذكية عن السالفة عشان تصيدوا الجاسوس!
          </p>
        </motion.div>
        <NeonButton onClick={onVote} className="w-full text-xl py-6 mt-8" variant="primary">
          صوّتوا الآن!
          <Vote className="w-6 h-6 mr-2" />
        </NeonButton>
      </div>
    </Layout>
  );
}

function VoteScreen({ onReveal, allPlayers, spyIndex }: { onReveal: () => void; allPlayers: any[]; spyIndex: number }) {
  const [isRevealing, setIsRevealing] = useState(false);
  const [displayIndex, setDisplayIndex] = useState(0);
  const [isDone, setIsDone] = useState(false);

  const startReveal = () => {
    setIsRevealing(true);
    playSound("suspense");

    let count = 0;
    const interval = setInterval(() => {
      setDisplayIndex(Math.floor(Math.random() * allPlayers.length));
      count++;

      if (count > 20) {
        clearInterval(interval);
        setDisplayIndex(spyIndex);
        setIsDone(true);
        playSound("spy");
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#ff0000", "#ffffff", "#8B5CF6"],
        });
        if (navigator.vibrate) navigator.vibrate([300, 100, 300, 100, 300]);
      }
    }, 100);
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full gap-8 text-center">
        {!isRevealing ? (
          <>
            <h2 className="text-4xl font-black text-glow">من الجاسوس؟</h2>
            <p className="text-muted-foreground text-lg">صوتوا على الشخص اللي تشكوا فيه!</p>
            <div className="w-48 h-48 bg-destructive/10 border-4 border-dashed border-destructive/30 rounded-full flex items-center justify-center animate-pulse">
              <Vote className="w-20 h-20 text-destructive/50" />
            </div>
            <NeonButton onClick={startReveal} variant="danger" className="w-full text-xl py-6 mt-8">
              اكشف الجاسوس! 🔥
            </NeonButton>
          </>
        ) : (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="space-y-8 w-full"
          >
            <h2 className="text-3xl font-bold text-muted-foreground">الجاسوس هو...</h2>
            <div
              className={cn(
                "text-6xl font-black p-10 rounded-3xl border-4 transition-all duration-300",
                isDone
                  ? "bg-destructive border-destructive text-white scale-110 shadow-[0_0_50px_rgba(239,68,68,0.5)]"
                  : "bg-white/5 border-white/20 text-white dark:text-white light:text-slate-900"
              )}
            >
              {allPlayers[displayIndex].name}
            </div>
            {isDone && (
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
                <NeonButton onClick={onReveal} className="w-full py-6 text-xl mt-4">
                  كمل اللعبة
                </NeonButton>
              </motion.div>
            )}
          </motion.div>
        )}
      </div>
    </Layout>
  );
}

function GuessScreen({
  spyName,
  options,
  result,
  onGuess,
  onEnd,
}: {
  spyName: string;
  options: string[];
  result: "correct" | "wrong" | null;
  onGuess: (opt: string) => void;
  onEnd: () => void;
}) {
  return (
    <Layout>
      <div className="flex flex-col h-full gap-8 py-4">
        <header className="text-center space-y-4">
          <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} className="text-6xl mb-4">
            🎭
          </motion.div>
          <h2 className="text-3xl font-black text-destructive">الجاسوس هو: {spyName}</h2>
          <p className="text-muted-foreground">يا {spyName}، عندك فرصة أخيرة! وش هي السالفة؟</p>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto">
          {options.map((opt, i) => (
            <motion.button
              key={opt}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => !result && onGuess(opt)}
              disabled={!!result}
              className={cn(
                "w-full p-5 rounded-2xl border-2 transition-all text-xl font-bold text-white dark:text-white light:text-slate-900",
                !result && "bg-white/5 border-white/10 hover:border-primary hover:bg-primary/10",
                result === "correct" && opt === options.find((o) => o === opt) && "bg-green-500/20 border-green-500",
                result === "wrong" && opt === options.find((o) => o === opt) && "bg-destructive/20 border-destructive"
              )}
            >
              {opt}
            </motion.button>
          ))}
        </div>

        <AnimatePresence>
          {result && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-4">
              <div
                className={cn(
                  "text-3xl font-black p-4 rounded-2xl",
                  result === "correct" ? "bg-green-500/20 text-green-400" : "bg-destructive/20 text-destructive"
                )}
              >
                {result === "correct" ? "صح! الجاسوس فنان 🔥" : "خطأ! الجاسوس انصاد 🙊"}
              </div>
              <NeonButton onClick={onEnd} className="w-full py-5">
                النتائج النهائية
              </NeonButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Layout>
  );
}

function EndScreen({ spyName, onReset, onRepeat }: { spyName: string; onReset: () => void; onRepeat: () => void }) {
  useEffect(() => {
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#8B5CF6", "#06B6D4", "#ffffff"],
    });
    playSound("reveal");
  }, []);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center h-full gap-8 text-center">
        <h1 className="text-5xl font-black text-glow text-white dark:text-white light:text-slate-900">جولة ممتعة!</h1>
        <div className="bg-white/5 p-8 rounded-3xl border border-white/10 w-full space-y-6">
          <p className="text-muted-foreground">ودكم تكملون؟</p>
          <div className="grid grid-cols-1 gap-4">
            <NeonButton onClick={onRepeat} className="py-6 text-xl" variant="secondary">
              <RotateCcw className="w-6 h-6 mr-2" />
              جولة ثانية بنفس القسم
            </NeonButton>
            <NeonButton onClick={onReset} className="py-6 text-xl" variant="ghost">
              تغيير القسم / اللاعبين
            </NeonButton>
          </div>
        </div>
      </div>
    </Layout>
  );
}

function getCategoryIcon(cat: Category): string {
  const map: Record<Category, string> = {
    اكلات: "🍔",
    مسلسلات: "📺",
    حيوانات: "🦁",
    ملابس: "👕",
    انمي: "🎌",
    سبيستون: "🚀",
    "مهن ووظائف": "👨‍⚕️",
    "دول ومدن": "🌍",
    كيبوب: "🎤",
    كيدراما: "🎬",
  };
  return map[cat] || "🎲";
}

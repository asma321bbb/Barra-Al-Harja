import { db } from "./db";
import {
  game_sessions,
  type InsertSession,
  type GameSession
} from "@shared/schema";

export interface IStorage {
  createSession(session: InsertSession): Promise<GameSession>;
}

export class DatabaseStorage implements IStorage {
  async createSession(insertSession: InsertSession): Promise<GameSession> {
    const [session] = await db
      .insert(game_sessions)
      .values(insertSession)
      .returning();
    return session;
  }
}

export const storage = new DatabaseStorage();

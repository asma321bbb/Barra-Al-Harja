import { pgTable, text, serial, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We are keeping the backend minimal as requested, but setting up 
// a basic schema is required for the project structure.
// These tables won't be critical for the client-side game logic.

export const game_sessions = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  startedAt: timestamp("started_at").defaultNow(),
  playerCount: serial("player_count"),
  category: text("category"),
});

export const insertSessionSchema = createInsertSchema(game_sessions).omit({ id: true, startedAt: true });

export type GameSession = typeof game_sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
